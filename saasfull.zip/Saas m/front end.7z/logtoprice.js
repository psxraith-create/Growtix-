function login(){

let email = document.getElementById("email").value;

if(email){
window.location.href="pricing.html";
}
}