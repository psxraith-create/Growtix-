from fastapi import FastAPI, UploadFile, File
import shutil
import os

from engine.data_loader import load_data
from engine.analyzer import analyze_data
from engine.report import generate_report

app = FastAPI()

UPLOAD_FOLDER = "data"
OUTPUT_FILE = "output/business_report.xlsx"


@app.get("/")
def home():
    return {"message": "Business Health API Running"}


@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)

    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Load data
    data = load_data(filepath)

    # Analyze
    summary = analyze_data(data)

    # Generate report
    generate_report(summary, OUTPUT_FILE)

    return {
        "message": "Report generated successfully",
        "report_file": OUTPUT_FILE
    }