# core/profit_loss.py
import pandas as pd

def calculate_profit_loss(df):
    """
    Calculate product-wise profit/loss.
    """
    # Calculate revenue and cost per row
    df = df.copy()
    df['Revenue'] = df['Quantity'] * df['Selling_Price']
    df['Total_Cost'] = df['Quantity'] * df['Cost_Price']
    df['Profit'] = df['Revenue'] - df['Total_Cost']

    # Group by product
    product_summary = df.groupby('Product').agg({
        'Revenue': 'sum',
        'Total_Cost': 'sum',
        'Profit': 'sum',
        'Quantity': 'sum'
    }).reset_index()

    # Sort by profit
    product_summary = product_summary.sort_values('Profit', ascending=False)

    # Top profitable and loss-making
    top_profitable = product_summary.head(3)
    top_loss = product_summary.tail(3).sort_values('Profit')

    return {
        'product_summary': product_summary,
        'top_profitable': top_profitable,
        'top_loss': top_loss
    }