# business_health_reporter/core/health_score_engine.py
import pandas as pd

def calculate_health_scores(df, roi=None, conversion_rate=None, churn_rate=None, automation_used=None):
    """
    Compute System Performance Score (1–10) and Overall Business Health Score (1–100).
    Uses ROI, conversion rate, churn rate, and automation usage as inputs.
    If not provided, tries to calculate from df.
    """
    insights = {}

    try:
        # If not provided, try to get from df or assume
        if roi is None:
            # Calculate simple ROI if possible
            if 'Revenue' in df.columns and 'Expenses' in df.columns:
                total_revenue = df['Revenue'].sum()
                total_expenses = df['Expenses'].sum()
                roi = ((total_revenue - total_expenses) / total_expenses) * 100 if total_expenses != 0 else 0

        if conversion_rate is None:
            if 'Conversions' in df.columns and 'Website Traffic' in df.columns:
                total_conversions = df['Conversions'].sum()
                total_traffic = df['Website Traffic'].sum()
                conversion_rate = (total_conversions / total_traffic) * 100 if total_traffic != 0 else 0

        if churn_rate is None:
            if 'Lost Customers' in df.columns and 'Total Customers' in df.columns:
                total_lost = df['Lost Customers'].sum()
                avg_total = df['Total Customers'].mean()
                churn_rate = (total_lost / avg_total) * 100 if avg_total != 0 else 0

        if automation_used is None:
            automation_used = 'Automation / AI Systems Used' in df.columns and not df['Automation / AI Systems Used'].dropna().empty

        # System Performance Score (1-10)
        # Based on automation usage
        if automation_used:
            system_score = 8  # assume high if automation is used
        else:
            system_score = 5  # medium otherwise
        insights['system_performance_score'] = system_score

        # Overall Business Health Score (1-100)
        # Based on ROI, conversion_rate, churn_rate
        score = 50  # base

        if roi is not None:
            if roi > 50:
                score += 20
            elif roi > 20:
                score += 10
            elif roi < 0:
                score -= 20

        if conversion_rate is not None:
            if conversion_rate > 5:
                score += 10
            elif conversion_rate < 1:
                score -= 10

        if churn_rate is not None:
            if churn_rate < 5:
                score += 10
            elif churn_rate > 20:
                score -= 20

        insights['overall_business_health_score'] = max(1, min(100, score))

    except Exception as e:
        insights['error'] = str(e)
        insights['system_performance_score'] = 5
        insights['overall_business_health_score'] = 50

    return insights