# business_health_reporter/core/marketing_engine.py
import pandas as pd

def analyze_marketing(df):
    """
    Analyze marketing metrics: Website Traffic, Conversions, Conversion Rate, Marketing Spend, CAC, Lead Sources.
    Returns a dictionary with averages and top lead sources.
    """
    insights = {}

    try:
        # Website Traffic
        if 'Website Traffic' in df.columns:
            insights['avg_website_traffic'] = df['Website Traffic'].mean()
        else:
            insights['avg_website_traffic'] = None

        # Conversions
        if 'Conversions' in df.columns:
            insights['total_conversions'] = df['Conversions'].sum()
        else:
            insights['total_conversions'] = None

        # Conversion Rate (%)
        if 'Conversions' in df.columns and 'Website Traffic' in df.columns:
            total_conversions = df['Conversions'].sum()
            total_traffic = df['Website Traffic'].sum()
            insights['conversion_rate'] = (total_conversions / total_traffic) * 100 if total_traffic != 0 else 0
        else:
            insights['conversion_rate'] = None

        # Marketing Spend
        if 'Marketing Spend (₹)' in df.columns:
            insights['total_marketing_spend'] = df['Marketing Spend (₹)'].sum()
        else:
            insights['total_marketing_spend'] = None

        # CAC (Customer Acquisition Cost)
        if 'Marketing Spend (₹)' in df.columns and 'New Customers' in df.columns:
            total_spend = df['Marketing Spend (₹)'].sum()
            total_new_customers = df['New Customers'].sum()
            insights['cac'] = total_spend / total_new_customers if total_new_customers != 0 else None
        else:
            insights['cac'] = None

        # Lead Sources
        if 'Lead Sources' in df.columns:
            # Assuming Lead Sources is a string column, get top sources
            lead_counts = df['Lead Sources'].value_counts()
            insights['top_lead_sources'] = lead_counts.head(5).to_dict()
        else:
            insights['top_lead_sources'] = {}

    except Exception as e:
        # Fail safely
        insights['error'] = str(e)

    return insights
