# main.py
from core.data_loader import load_data
from core.profit_loss import calculate_profit_loss
from core.reason_engine import analyze_reasons
from core.investment_engine import calculate_roi
from core.supplier_analysis import analyze_suppliers
from reports.summary_report import generate_summary_report
from charts.charts import generate_charts

def main():
    # Load data
    data_file = "data/Jan_2025_Raw.xlsx"
    df = load_data(data_file)

    # Calculate profit/loss
    profit_loss = calculate_profit_loss(df)

    # Analyze reasons
    reasons = analyze_reasons(df, profit_loss)

    # Calculate ROI
    roi = calculate_roi(df)

    # Analyze suppliers
    supplier_analysis = analyze_suppliers(df)

    # Generate summary report
    generate_summary_report(profit_loss, reasons, roi, supplier_analysis)

    # Generate charts
    generate_charts(df, profit_loss)

    print("Business Health Reporter completed successfully!")

if __name__ == "__main__":
    main()